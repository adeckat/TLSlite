import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        DNSServer dnsServer = new DNSServer();
        dnsServer.listen();
    }
}
